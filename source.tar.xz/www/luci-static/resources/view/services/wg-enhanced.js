'use strict';
'require view';
'require fs';
'require ui';
var tool='/usr/libexec/wg-enhanced';
function run(args){return fs.exec(tool,args).then(function(r){if(r.code!==0)throw new Error((r.stderr||r.stdout||'操作失败').trim());return (r.stdout||'').trim();});}
function el(id){return document.getElementById(id);}
function notice(t,bad){ui.addNotification(null,E('p',{},t),bad?'error':'info');}
function download(hex){hex=hex.replace(/\s/g,'');if(!hex||hex.length%2||/[^0-9a-f]/i.test(hex))throw new Error('备份数据无效');var data=new Uint8Array(hex.length/2);for(var i=0;i<data.length;i++)data[i]=parseInt(hex.slice(i*2,i*2+2),16);if(data[0]!==31||data[1]!==139)throw new Error('不是 gzip 文件');var url=URL.createObjectURL(new Blob([data],{type:'application/gzip'}));var a=document.createElement('a');a.href=url;a.download='wireguard-'+new Date().toISOString().replace(/[-:]/g,'').slice(0,15).replace('T','-')+'.tar.gz';document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},3000);}
return view.extend({
 load:function(){return Promise.all([run(['status']).catch(function(){return ''; }),run(['logs']).catch(function(){return '';})]);},
 log:function(){return run(['logs']).then(function(s){el('wgex-log').textContent=s||'暂无日志';});},
 backup:function(){var self=this;el('wgex-status').textContent='正在生成备份…';return run(['backup']).then(function(stamp){el('wgex-status').textContent='备份完成：'+stamp+'（临时保存，重启后清除）';notice('备份成功，请点击下载备份包保存到电脑');return self.log();}).catch(function(e){el('wgex-status').textContent='备份失败';notice(e.message,true);});},
 getBackup:function(){el('wgex-status').textContent='正在读取备份…';return run(['read']).then(function(hex){download(hex);el('wgex-status').textContent='下载已发起';}).catch(function(e){notice(e.message,true);});},
 upload:function(){var self=this,file=el('wgex-upload').files[0];if(!file){notice('请选择备份包',true);return;}if(!/\.tar\.gz$/.test(file.name)||file.size<50||file.size>2097152){notice('请选择不超过 2MB 的 tar.gz 备份包',true);return;}var id=String(Date.now())+'-'+String(Math.floor(Math.random()*100000));return file.arrayBuffer().then(function(buf){var b=new Uint8Array(buf);return run(['upload-start',id]).then(function(){var pos=0;function next(){if(pos>=b.length)return run(['upload-finish',id]);var end=Math.min(pos+1024,b.length),oct='';for(var i=pos;i<end;i++)oct+='\\0'+b[i].toString(8).padStart(3,'0');pos=end;el('wgex-status').textContent='上传中 '+Math.floor(100*pos/b.length)+'%';return run(['upload-append',id,oct]).then(next);}return next();});}).then(function(){el('wgex-status').textContent='备份上传并校验成功，可以一键恢复';el('wgex-upload').value='';notice('上传成功');return self.log();}).catch(function(e){notice(e.message,true);});},
 restore:function(){var self=this;if(!confirm('确认恢复上传的 WireGuard 备份？\n将修改网络和防火墙配置，建议通过网线连接路由器操作。'))return;el('wgex-status').textContent='正在恢复…';return run(['restore']).then(function(s){el('wgex-status').textContent=s;notice(s);return self.log();}).catch(function(e){el('wgex-status').textContent='恢复失败';notice(e.message,true);});},
 render:function(d){return E('div',{class:'cbi-map'},[
 E('h2',{},'WireGuard 备份与恢复 v1.0.0-13'),
 E('div',{class:'cbi-section'},[
 E('div',{style:'display:flex;gap:10px;flex-wrap:wrap;margin:14px 0'},[
 E('button',{class:'btn cbi-button cbi-button-action',click:ui.createHandlerFn(this,'backup')},'一键备份'),
 E('button',{class:'btn cbi-button',click:ui.createHandlerFn(this,'getBackup')},'下载备份包')]),
 E('div',{style:'display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:14px 0'},[
 E('button',{class:'btn cbi-button cbi-button-negative',click:ui.createHandlerFn(this,'restore')},'一键恢复'),
 E('input',{id:'wgex-upload',type:'file',accept:'.tar.gz,application/gzip'}),
 E('button',{class:'btn cbi-button',click:ui.createHandlerFn(this,'upload')},'上传备份')]),
 E('p',{id:'wgex-status'},d[0]?'上次临时备份：'+d[0]:'尚未生成临时备份'),
 E('p',{},'备份和上传文件仅临时保存在 /tmp，重启后会消失。下载文件包含私钥，请妥善保管。')]),
 E('div',{class:'cbi-section'},[E('h3',{},'操作日志'),E('button',{class:'btn cbi-button',click:ui.createHandlerFn(this,'log')},'刷新日志'),E('pre',{id:'wgex-log',style:'white-space:pre-wrap;max-height:240px;overflow:auto'},d[1]||'暂无日志')])]);},
 handleSaveApply:null,handleSave:null,handleReset:null
});
